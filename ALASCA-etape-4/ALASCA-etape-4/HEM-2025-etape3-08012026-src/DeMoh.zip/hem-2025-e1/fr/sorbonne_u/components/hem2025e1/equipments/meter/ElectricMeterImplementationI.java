package fr.sorbonne_u.components.hem2025e1.equipments.meter;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to implement a mock-up
// of household energy management system.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import fr.sorbonne_u.alasca.physical_data.SignalData;
import fr.sorbonne_u.components.hem2025e1.equipments.hairdryer.HairDryer;
import fr.sorbonne_u.exceptions.AssertionChecking;
import fr.sorbonne_u.alasca.physical_data.Measure;
import fr.sorbonne_u.alasca.physical_data.MeasurementUnit;

// -----------------------------------------------------------------------------
/**
 * The interface <code>ElectricMeterImplementationI</code> defines the services
 * implemented by an electric meter component.
 *
 * <p><strong>Description</strong></p>
 * 
 * <p><strong>Invariants</strong></p>
 * 
 * <pre>
 * invariant	{@code true}	// no more invariant
 * </pre>
 * 
 * <p>Created on : 2023-09-19</p>
 * 
 * @author	<a href="mailto:Jacques.Malenfant@lip6.fr">Jacques Malenfant</a>
 */
public interface		ElectricMeterImplementationI
{
	// -------------------------------------------------------------------------
	// Constants and variables
	// -------------------------------------------------------------------------

	/** measurement unit for power used in this appliance.					*/
	public static final MeasurementUnit	POWER_UNIT = MeasurementUnit.AMPERES;
	/** measurement unit for tension used in this appliance.				*/
	public static final MeasurementUnit	TENSION_UNIT = MeasurementUnit.VOLTS;

	// -------------------------------------------------------------------------
	// Invariants
	// -------------------------------------------------------------------------

	/**
	 * return true if the static invariants are observed, false otherwise.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * post	{@code true}	// no postcondition.
	 * </pre>
	 *
	 * @return	true if the static invariants are observed, false otherwise.
	 */
	public static boolean	staticInvariants()
	{
		boolean ret = true;
		ret &= AssertionChecking.checkStaticInvariant(
				POWER_UNIT != null && TENSION_UNIT != null,
				HairDryer.class,
				"POWER_UNIT != null && TENSION_UNIT != null");
		return ret;
	}

	/**
	 * return the tension in the electric circuits of this meter.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code return.getData() > 0.0}
	 * post	{@code return.getMeasurementUnit().equals(TENSION_UNIT)}
	 * </pre>
	 *
	 * @return				the tension in the electric circuits of this meter.
	 * @throws Exception	<i>to do</i>.
	 */
	public Measure<Double>	getTension() throws Exception;

	/**
	 * return the current total electric consumption in amperes.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code return != null}
	 * post	{@code return.isSingle()}
	 * post	{@code return.getMeasure().getData() >= 0.0}
	 * post	{@code return.getMeasure().getMeasurementUnit().equals(POWER_UNIT)}
	 * </pre>
	 *
	 * @return				the current total electric consumption in watts.
	 * @throws Exception	<i>to do</i>.
	 */
	public SignalData<Double>	getCurrentConsumption() throws Exception;

	/**
	 * return the current total electric power production in watts.
	 * 
	 * <p><strong>Contract</strong></p>
	 * 
	 * <pre>
	 * pre	{@code true}	// no precondition.
	 * post	{@code return != null}
	 * post	{@code return.isSingle()}
	 * post	{@code return.getMeasure().getData() >= 0.0}
	 * post	{@code return.getMeasure().getMeasurementUnit().equals(POWER_UNIT)}
	 * </pre>
	 *
	 * @return				the current total electric power production in amperes.
	 * @throws Exception	<i>to do</i>.
	 */
	public SignalData<Double>	getCurrentProduction() throws Exception;
}
// -----------------------------------------------------------------------------
