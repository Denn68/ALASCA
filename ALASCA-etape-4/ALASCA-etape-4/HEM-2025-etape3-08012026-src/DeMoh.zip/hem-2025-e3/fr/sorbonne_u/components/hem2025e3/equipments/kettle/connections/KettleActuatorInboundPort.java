package fr.sorbonne_u.components.hem2025e3.equipments.kettle.connections;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to provide a
// basic component programming model to program with components
// real time distributed applications in the Java programming language.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.hem2025e1.equipments.kettle.KettleInternalControlI;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleActuatorCI;
import fr.sorbonne_u.components.ports.AbstractInboundPort;
import fr.sorbonne_u.exceptions.PreconditionException;

// -----------------------------------------------------------------------------
/**
 * The class <code>KettleActuatorInboundPort</code> implements the inbound port
 * for the {@code KettleActuatorCI} component interface.
 *
 * <p>
 * <strong>Description</strong>
 * </p>
 * 
 * <p>
 * <strong>Implementation Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * <strong>Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * Created on : 2026-02-03
 * </p>
 * 
 * @author Team DeMoh
 */
public class KettleActuatorInboundPort
        extends AbstractInboundPort
        implements KettleActuatorCI {
    private static final long serialVersionUID = 1L;

    /**
     * create the inbound port.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * owner instanceof KettleInternalControlI
     * }
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param owner component that owns this port.
     * @throws Exception <i>to do</i>.
     */
    public KettleActuatorInboundPort(ComponentI owner)
            throws Exception {
        super(KettleActuatorCI.class, owner);
        assert owner instanceof KettleInternalControlI : new PreconditionException(
                "owner instanceof KettleInternalControlI");
    }

    /**
     * create the inbound port.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * owner instanceof KettleInternalControlI
     * }
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param uri   unique identifier of the port.
     * @param owner component that owns this port.
     * @throws Exception <i>to do</i>.
     */
    public KettleActuatorInboundPort(
            String uri,
            ComponentI owner) throws Exception {
        super(uri, KettleActuatorCI.class, owner);
        assert owner instanceof KettleInternalControlI : new PreconditionException(
                "owner instanceof KettleInternalControlI");
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleActuatorCI#startHeating()
     */
    @Override
    public void startHeating() throws Exception {
        this.getOwner().handleRequest(
                o -> {
                    ((KettleInternalControlI) o).startHeating();
                    return null;
                });
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleActuatorCI#stopHeating()
     */
    @Override
    public void stopHeating() throws Exception {
        this.getOwner().handleRequest(
                o -> {
                    ((KettleInternalControlI) o).stopHeating();
                    return null;
                });
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleActuatorCI#startKeepingWarm()
     */
    @Override
    public void startKeepingWarm() throws Exception {
        this.getOwner().handleRequest(
                o -> {
                    ((KettleInternalControlI) o).startKeepingWarm();
                    return null;
                });
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleActuatorCI#stopKeepingWarm()
     */
    @Override
    public void stopKeepingWarm() throws Exception {
        this.getOwner().handleRequest(
                o -> {
                    ((KettleInternalControlI) o).stopKeepingWarm();
                    return null;
                });
    }
}
// -----------------------------------------------------------------------------
