package fr.sorbonne_u.components.hem2025e3.equipments.kettle.connections;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to provide a
// basic component programming model to program with components
// real time distributed applications in the Java programming language.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import fr.sorbonne_u.components.ComponentI;
import fr.sorbonne_u.components.exceptions.BCMException;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettlePushImplementationI;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleSensorDataCI;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.sensor_data.KettleSensorDataI;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.sensor_data.KettleStateSensorData;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.sensor_data.KettleTemperatureSensorData;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.sensor_data.HeatingSensorData;
import fr.sorbonne_u.components.interfaces.DataRequiredCI;
import fr.sorbonne_u.components.ports.AbstractDataOutboundPort;
import java.util.concurrent.TimeUnit;

// -----------------------------------------------------------------------------
/**
 * The class <code>KettleSensorDataOutboundPort</code> implements the outbound
 * port for the {@code KettleSensorDataCI} component data interface.
 *
 * <p>
 * <strong>Description</strong>
 * </p>
 * 
 * <p>
 * <strong>Implementation Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * <strong>Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * Created on : 2026-02-03
 * </p>
 * 
 * @author Team DeMoh
 */
public class KettleSensorDataOutboundPort
        extends AbstractDataOutboundPort
        implements KettleSensorDataCI.KettleSensorRequiredPullCI {
    // -------------------------------------------------------------------------
    // Constants and variables
    // -------------------------------------------------------------------------

    private static final long serialVersionUID = 1L;

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * create the outbound port.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * true
     * }	// no precondition.
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param owner component that owns this port.
     * @throws Exception <i>to do</i>.
     */
    public KettleSensorDataOutboundPort(ComponentI owner)
            throws Exception {
        super(DataRequiredCI.PullCI.class,
                DataRequiredCI.PushCI.class, owner);
    }

    /**
     * create the outbound port.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * true
     * }	// no precondition.
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param uri   unique identifier of the port.
     * @param owner component that owns this port.
     * @throws Exception <i>to do</i>.
     */
    public KettleSensorDataOutboundPort(
            String uri,
            ComponentI owner) throws Exception {
        super(uri, KettleSensorDataCI.KettleSensorRequiredPullCI.class,
                DataRequiredCI.PushCI.class, owner);
    }

    // -------------------------------------------------------------------------
    // Methods
    // -------------------------------------------------------------------------

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleSensorDataCI.KettleSensorCI#heatingPullSensor()
     */
    @Override
    public HeatingSensorData heatingPullSensor()
            throws Exception {
        return ((KettleSensorDataCI.KettleSensorRequiredPullCI) this.getConnector()).heatingPullSensor();
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleSensorDataCI.KettleSensorCI#currentTemperaturePullSensor()
     */
    @Override
    public KettleTemperatureSensorData currentTemperaturePullSensor()
            throws Exception {
        return ((KettleSensorDataCI.KettleSensorRequiredPullCI) this.getConnector()).currentTemperaturePullSensor();
    }

    /**
     * @see fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleSensorDataCI.KettleSensorCI#startTemperaturePushSensor(long,
     *      java.util.concurrent.TimeUnit)
     */
    @Override
    public void startTemperaturePushSensor(
            long controlPeriod,
            TimeUnit tu) throws Exception {
        ((KettleSensorDataCI.KettleSensorRequiredPullCI) this.getConnector()).startTemperaturePushSensor(controlPeriod,
                tu);
    }

    /**
     * @see fr.sorbonne_u.components.interfaces.DataRequiredCI.PushCI#receive(fr.sorbonne_u.components.interfaces.DataRequiredCI.DataI)
     */
    @Override
    public void receive(DataRequiredCI.DataI d) throws Exception {
        assert d instanceof KettleSensorDataI : new BCMException("d instanceof KettleSensorDataI");

        if (d instanceof KettleStateSensorData) {
            this.getOwner().runTask(
                    o -> ((KettlePushImplementationI) o).processKettleState(
                            ((KettleStateSensorData) d).getMeasure().getData()));
        } else if (d instanceof KettleTemperatureSensorData) {
            this.getOwner().runTask(
                    o -> ((KettlePushImplementationI) o).processTemperature(
                            (KettleTemperatureSensorData) d));
        } else {
            throw new BCMException("Unknown kettle sensor data: " + d);
        }
    }
}
// -----------------------------------------------------------------------------
