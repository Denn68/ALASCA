package fr.sorbonne_u.components.hem2025e3.equipments.kettle.sensor_data;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to provide a
// basic component programming model to program with components
// distributed applications in the Java programming language.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import fr.sorbonne_u.alasca.physical_data.SignalData;
import fr.sorbonne_u.alasca.physical_data.TimedMeasure;
import fr.sorbonne_u.utils.aclocks.AcceleratedClock;

// -----------------------------------------------------------------------------
/**
 * The class <code>KettleTemperatureSensorData</code> implements a sensor data
 * object containing a measure of water temperature.
 *
 * <p>
 * <strong>Description</strong>
 * </p>
 * 
 * <p>
 * <strong>Implementation Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * <strong>Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * Created on : 2026-02-03
 * </p>
 * 
 * @author Team DeMoh
 */
public class KettleTemperatureSensorData
        extends SignalData<Double>
        implements KettleSensorDataI {
    // -------------------------------------------------------------------------
    // Constants and variables
    // -------------------------------------------------------------------------

    private static final long serialVersionUID = 1L;

    // -------------------------------------------------------------------------
    // Constructors
    // -------------------------------------------------------------------------

    /**
     * create a new temperature sensor data from the given {@code TimedMeasure}
     * at the current time under the hardware clock time reference.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * true
     * }	// no precondition.
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param temperature temperature measure to be provided as sensor data.
     */
    public KettleTemperatureSensorData(
            TimedMeasure<Double> temperature) {
        super(temperature);
    }

    /**
     * create a new temperature sensor data from the given {@code TimedMeasure}
     * at the current time under the given clock time reference.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * true
     * }	// no precondition.
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @param ac          accelerated clock used for time stamping.
     * @param temperature temperature measure to be provided as sensor data.
     */
    public KettleTemperatureSensorData(
            AcceleratedClock ac,
            TimedMeasure<Double> temperature) {
        super(ac, temperature);
    }

    // -------------------------------------------------------------------------
    // Methods
    // -------------------------------------------------------------------------

    /**
     * return the temperature value from this sensor data.
     * 
     * <p>
     * <strong>Contract</strong>
     * </p>
     * 
     * <pre>
     * pre	{@code
     * true
     * }	// no precondition.
     * post	{@code
     * true
     * }	// no postcondition.
     * </pre>
     *
     * @return the temperature value in celsius.
     */
    public double getTemperature() {
        return this.getMeasure().getData();
    }
}
// -----------------------------------------------------------------------------
