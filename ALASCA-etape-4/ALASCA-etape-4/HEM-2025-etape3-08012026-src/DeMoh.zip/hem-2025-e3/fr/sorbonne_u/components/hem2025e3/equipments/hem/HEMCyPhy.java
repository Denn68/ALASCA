package fr.sorbonne_u.components.hem2025e3.equipments.hem;

// Copyright Jacques Malenfant, Sorbonne Universite.
// Jacques.Malenfant@lip6.fr
//
// This software is a computer program whose purpose is to implement a mock-up
// of household energy management system.
//
// This software is governed by the CeCILL-C license under French law and
// abiding by the rules of distribution of free software.  You can use,
// modify and/ or redistribute the software under the terms of the
// CeCILL-C license as circulated by CEA, CNRS and INRIA at the following
// URL "http://www.cecill.info".
//
// As a counterpart to the access to the source code and  rights to copy,
// modify and redistribute granted by the license, users are provided only
// with a limited warranty  and the software's author,  the holder of the
// economic rights,  and the successive licensors  have only  limited
// liability. 
//
// In this respect, the user's attention is drawn to the risks associated
// with loading,  using,  modifying and/or developing or reproducing the
// software by the user in light of its specific status of free software,
// that may mean  that it is complicated to manipulate,  and  that  also
// therefore means  that it is reserved for developers  and  experienced
// professionals having in-depth computer knowledge. Users are therefore
// encouraged to load and test the software's suitability as regards their
// requirements in conditions enabling the security of their systems and/or 
// data to be ensured and,  more generally, to use and operate it in the 
// same conditions as regards security. 
//
// The fact that you are presently reading this means that you have had
// knowledge of the CeCILL-C license and that you accept its terms.

import fr.sorbonne_u.components.AbstractComponent;
import fr.sorbonne_u.components.annotations.OfferedInterfaces;
import fr.sorbonne_u.components.annotations.RequiredInterfaces;
import fr.sorbonne_u.components.cyphy.ExecutionMode;
import fr.sorbonne_u.components.cyphy.utils.aclocks.ClocksServerWithSimulation;
import fr.sorbonne_u.components.exceptions.BCMException;
import fr.sorbonne_u.components.exceptions.ComponentShutdownException;
import fr.sorbonne_u.components.exceptions.ComponentStartException;
import fr.sorbonne_u.components.hem2025.bases.AdjustableCI;
import fr.sorbonne_u.components.hem2025.bases.RegistrationCI;
import fr.sorbonne_u.components.hem2025.bases.connector_generator.AdapterDescriptor;
import fr.sorbonne_u.components.hem2025.bases.connector_generator.DescriptorReader;
import fr.sorbonne_u.components.hem2025.bases.connector_generator.DynamicConnectorFactory;
import fr.sorbonne_u.components.hem2025e1.equipments.batteries.BatteriesCI;
import fr.sorbonne_u.components.hem2025e1.equipments.batteries.connections.BatteriesConnector;
import fr.sorbonne_u.components.hem2025e1.equipments.batteries.connections.BatteriesOutboundPort;
import fr.sorbonne_u.components.hem2025e1.equipments.generator.GeneratorCI;
import fr.sorbonne_u.components.hem2025e1.equipments.generator.GeneratorUnitTester;
import fr.sorbonne_u.components.hem2025e1.equipments.generator.connections.GeneratorConnector;
import fr.sorbonne_u.components.hem2025e1.equipments.generator.connections.GeneratorOutboundPort;
import fr.sorbonne_u.components.hem2025e1.equipments.heater.Heater;
import fr.sorbonne_u.components.hem2025e1.equipments.hem.AdjustableOutboundPort;
import fr.sorbonne_u.components.hem2025e1.equipments.hem.HeaterConnector;
//import fr.sorbonne_u.components.hem2025e1.equipments.hem.WashingMachineConnector;
import fr.sorbonne_u.components.hem2025e1.equipments.hem.RegistrationInboundPort;
import fr.sorbonne_u.components.hem2025e1.equipments.meter.ElectricMeterCI;
import fr.sorbonne_u.components.hem2025e1.equipments.meter.ElectricMeterUnitTester;
import fr.sorbonne_u.components.hem2025e1.equipments.meter.connections.ElectricMeterConnector;
import fr.sorbonne_u.components.hem2025e1.equipments.meter.connections.ElectricMeterOutboundPort;
import fr.sorbonne_u.components.hem2025e1.equipments.solar_panel.SolarPanelCI;
import fr.sorbonne_u.components.hem2025e1.equipments.solar_panel.connections.SolarPanelConnector;
import fr.sorbonne_u.components.hem2025e1.equipments.solar_panel.connections.SolarPanelOutboundPort;
import fr.sorbonne_u.components.hem2025e3.equipments.batteries.BatteriesCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.batteries.BatteriesCyPhyUnitTester;
import fr.sorbonne_u.components.hem2025e3.equipments.generator.GeneratorCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.meter.ElectricMeterCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.solar_panel.SolarPanelCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.solar_panel.SolarPanelUnitTesterCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.washing_machine.WashingMachineCyPhy;
import fr.sorbonne_u.components.hem2025e3.equipments.kettle.KettleCyPhy;
//import fr.sorbonne_u.components.hem2025e1.equipments.hem.KettleConnector;
import fr.sorbonne_u.components.utils.tests.TestScenario;
import fr.sorbonne_u.components.utils.tests.TestsStatistics;
import java.util.Map;
import java.util.HashMap;
import fr.sorbonne_u.exceptions.ImplementationInvariantException;
import fr.sorbonne_u.exceptions.AssertionChecking;
import fr.sorbonne_u.exceptions.InvariantException;
import fr.sorbonne_u.exceptions.PreconditionException;
import fr.sorbonne_u.utils.aclocks.ClocksServer;

// -----------------------------------------------------------------------------
/**
 * The class <code>HEM</code> implements the basis for a household energy
 * management component.
 *
 * <p>
 * <strong>Description</strong>
 * </p>
 * 
 * <p>
 * As is, this component is only a very limited starting point for the actual
 * component. The given code is there only to ease the understanding of the
 * objectives, but most of it must be replaced to get the correct code.
 * Especially, no registration of the components representing the appliances
 * is given.
 * </p>
 * 
 * <p>
 * <strong>Implementation Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * true
 * }	// no more invariant
 * </pre>
 * 
 * <p>
 * <strong>Invariants</strong>
 * </p>
 * 
 * <pre>
 * invariant	{@code
 * X_RELATIVE_POSITION >= 0
 * }
 * invariant	{@code
 * Y_RELATIVE_POSITION >= 0
 * }
 * </pre>
 * 
 * <p>
 * Created on : 2021-09-09
 * </p>
 * 
 * @author <a href="mailto:Jacques.Malenfant@lip6.fr">Jacques Malenfant</a>
 */
@OfferedInterfaces(offered = { RegistrationCI.class })
@RequiredInterfaces(required = { AdjustableCI.class,
		ElectricMeterCI.class,
		BatteriesCI.class,
		SolarPanelCI.class,
		GeneratorCI.class })
public class HEMCyPhy
		extends AbstractComponent
		implements RegistrationInboundPort.RegistrationImplementorI {
	// -------------------------------------------------------------------------
	// Constants and variables
	// -------------------------------------------------------------------------

	/** when true, methods trace their actions. */
	public static boolean VERBOSE = false;
	/** when true, methods trace their actions. */
	public static boolean DEBUG = false;
	/** when tracing, x coordinate of the window relative position. */
	public static int X_RELATIVE_POSITION = 0;
	/** when tracing, y coordinate of the window relative position. */
	public static int Y_RELATIVE_POSITION = 0;
	/**
	 * standard reflection, inbound port URI for the {@code HEMCyPhy}
	 * component.
	 */
	public static final String REFLECTION_INBOUND_PORT_URI = "hem-RIP-URI";

	/** port to connect to the electric meter. */
	protected ElectricMeterOutboundPort meterop;

	/** port to connect to the batteries. */
	protected BatteriesOutboundPort batteriesop;
	/** port to connect to the solar panel. */
	protected SolarPanelOutboundPort solarPanelop;
	/** port to connect to the generator. */
	protected GeneratorOutboundPort generatorop;

	/**
	 * when true, manage the heater in a customised way, otherwise let
	 * it register itself as an adjustable appliance.
	 */
	protected boolean isPreFirstStep;
	/** port to connect to the heater when managed in a customised way. */
	protected AdjustableOutboundPort heaterop;

	// protected AdjustableOutboundPort kettleop;

	// protected AdjustableOutboundPort washingMachineop;

	/** URI du port entrant pour l'enregistrement des équipements. */
	public static final String REGISTRATION_INBOUND_PORT_URI = "HEM-REGISTRATION-INBOUND-PORT-URI";
	/** port entrant pour recevoir les demandes d'enregistrement. */
	protected RegistrationInboundPort registrationInboundPort;
	/** équipements enregistrés dynamiquement : uid -> AdjustableOutboundPort. */
	protected Map<String, AdjustableOutboundPort> registeredEquipments;
	/** compteur pour générer des noms de classes uniques pour les connecteurs. */
	protected int connectorCounter = 0;

	// Execution/Simulation

	/** one thread for the method execute. */
	protected static int NUMBER_OF_STANDARD_THREADS = 1;
	/** one thread to schedule this component test actions. */
	protected static int NUMBER_OF_SCHEDULABLE_THREADS = 1;

	/**
	 * current mode of execution of cyber-physical components in the
	 * application.
	 */
	protected ExecutionMode executionMode;
	/** test scenario under execution, if any. */
	protected TestScenario testScenario;

	// -------------------------------------------------------------------------
	// Invariants
	// -------------------------------------------------------------------------

	/**
	 * return true if the static implementation invariants are observed, false
	 * otherwise.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @return true if the static invariants are observed, false otherwise.
	 */
	public static boolean staticImplementationInvariants() {
		boolean ret = true;
		ret &= AssertionChecking.checkStaticImplementationInvariant(
				NUMBER_OF_STANDARD_THREADS >= 0,
				HEMCyPhy.class,
				"NUMBER_OF_STANDARD_THREADS >= 0");
		ret &= AssertionChecking.checkStaticImplementationInvariant(
				NUMBER_OF_SCHEDULABLE_THREADS >= 0,
				HEMCyPhy.class,
				"NUMBER_OF_SCHEDULABLE_THREADS");
		return ret;
	}

	/**
	 * return true if the implementation invariants are observed, false otherwise.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * hem != null
	 * }
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @param hem instance to be tested.
	 * @return true if the implementation invariants are observed, false otherwise.
	 */
	protected static boolean implementationInvariants(HEMCyPhy hem) {
		assert hem != null : new PreconditionException("hem != null");

		boolean ret = true;
		ret &= staticImplementationInvariants();
		return ret;
	}

	/**
	 * return true if the static invariants are observed, false otherwise.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @return true if the static invariants are observed, false otherwise.
	 */
	public static boolean staticInvariants() {
		boolean ret = true;
		ret &= AssertionChecking.checkStaticInvariant(
				X_RELATIVE_POSITION >= 0,
				HEMCyPhy.class,
				"X_RELATIVE_POSITION >= 0");
		ret &= AssertionChecking.checkStaticInvariant(
				Y_RELATIVE_POSITION >= 0,
				HEMCyPhy.class,
				"Y_RELATIVE_POSITION >= 0");
		return ret;
	}

	/**
	 * return true if the invariants are observed, false otherwise.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * hem != null
	 * }
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @param hem instance to be tested.
	 * @return true if the invariants are observed, false otherwise.
	 */
	protected static boolean invariants(HEMCyPhy hem) {
		assert hem != null : new PreconditionException("hem != null");

		boolean ret = true;
		ret &= staticInvariants();
		return ret;
	}

	// -------------------------------------------------------------------------
	// Constructors
	// -------------------------------------------------------------------------

	// Standard execution for manual tests (no test scenario and no simulation)

	/**
	 * create a household energy manager component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * !(this instanceof ComponentInterface)
	 * }
	 * post	{@code
	 * getCurrentExecutionMode().isStandard()
	 * }
	 * </pre>
	 *
	 */
	protected HEMCyPhy() {
		// 1 standard thread to execute the method execute and 1 schedulable
		// thread that is used to perform the tests
		super(NUMBER_OF_STANDARD_THREADS, NUMBER_OF_SCHEDULABLE_THREADS);

		// by default, consider this execution as one in the pre-first step
		// and manage the heater in a customised way.
		this.isPreFirstStep = true;

		this.executionMode = ExecutionMode.STANDARD;
		this.testScenario = null;

		// Initialisation de l'infrastructure d'enregistrement dynamique
		this.registeredEquipments = new HashMap<>();
		try {
			this.registrationInboundPort = new RegistrationInboundPort(
					REGISTRATION_INBOUND_PORT_URI, this);
			this.registrationInboundPort.publishPort();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		assert HEMCyPhy.implementationInvariants(this) : new ImplementationInvariantException(
				"HEMCyPhy.implementationInvariants(this)");
		assert HEMCyPhy.invariants(this) : new InvariantException("HEMCyPhy.invariants(this)");
	}

	// Test execution with test scenario

	/**
	 * create a household energy manager component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * !(this instanceof ComponentInterface)
	 * }
	 * pre	{@code
	 * executionMode != null && (executionMode.isIntegrationTest() || executionMode.isSILIntegrationTest())
	 * }
	 * pre	{@code
	 * testScenario != null
	 * }
	 * post	{@code
	 * getCurrentExecutionMode().equals(executionMode)
	 * }
	 * </pre>
	 *
	 * @param executionMode execution mode for the next run.
	 * @param testScenario  test scenario to be executed.
	 * @throws Exception <i>to do</i>.
	 */
	protected HEMCyPhy(
			ExecutionMode executionMode,
			TestScenario testScenario) throws Exception {
		// 1 standard thread to execute the method execute and 1 schedulable
		// thread that is used to perform the tests
		super(REFLECTION_INBOUND_PORT_URI,
				NUMBER_OF_STANDARD_THREADS,
				NUMBER_OF_SCHEDULABLE_THREADS);

		assert executionMode != null &&
				(executionMode.isIntegrationTest() ||
						executionMode.isSILIntegrationTest())
				: new PreconditionException(
						"executionMode != null && (executionMode."
								+ "isIntegrationTest() || "
								+ "executionMode.isSILIntegrationTest())");
		assert testScenario != null : new PreconditionException("testScenario != null");

		this.executionMode = executionMode;
		this.testScenario = testScenario;

		// by default, consider this execution as one in the pre-first step
		// and manage the heater in a customised way.
		this.isPreFirstStep = true;

		// Initialisation de l'infrastructure d'enregistrement dynamique
		this.registeredEquipments = new HashMap<>();
		this.registrationInboundPort = new RegistrationInboundPort(
				REGISTRATION_INBOUND_PORT_URI, this);
		this.registrationInboundPort.publishPort();

		if (VERBOSE) {
			this.tracer.get().setTitle("Home Energy Manager component");
			this.tracer.get().setRelativePosition(X_RELATIVE_POSITION,
					Y_RELATIVE_POSITION);
			this.toggleTracing();
		}

		assert HEMCyPhy.implementationInvariants(this) : new ImplementationInvariantException(
				"HEMCyPhy.implementationInvariants(this)");
		assert HEMCyPhy.invariants(this) : new InvariantException("HEMCyPhy.invariants(this)");
	}

	// -------------------------------------------------------------------------
	// Component life-cycle
	// -------------------------------------------------------------------------

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#start()
	 */
	@Override
	public synchronized void start() throws ComponentStartException {
		super.start();

		try {
			this.meterop = new ElectricMeterOutboundPort(this);
			this.meterop.publishPort();
			this.doPortConnection(
					this.meterop.getPortURI(),
					ElectricMeterCyPhy.ELECTRIC_METER_INBOUND_PORT_URI,
					ElectricMeterConnector.class.getCanonicalName());
			this.batteriesop = new BatteriesOutboundPort(this);
			this.batteriesop.publishPort();
			this.doPortConnection(
					batteriesop.getPortURI(),
					BatteriesCyPhy.STANDARD_INBOUND_PORT_URI,
					BatteriesConnector.class.getCanonicalName());
			this.solarPanelop = new SolarPanelOutboundPort(this);
			this.solarPanelop.publishPort();
			this.doPortConnection(
					this.solarPanelop.getPortURI(),
					SolarPanelCyPhy.STANDARD_INBOUND_PORT_URI,
					SolarPanelConnector.class.getCanonicalName());
			this.generatorop = new GeneratorOutboundPort(this);
			this.generatorop.publishPort();
			this.doPortConnection(
					this.generatorop.getPortURI(),
					GeneratorCyPhy.STANDARD_INBOUND_PORT_URI,
					GeneratorConnector.class.getCanonicalName());

			if (this.isPreFirstStep) {
				// in this case, connect using the statically customised
				// heater connector and keep a specific outbound port to
				// call the heater.
				this.heaterop = new AdjustableOutboundPort(this);
				this.heaterop.publishPort();
				this.doPortConnection(
						this.heaterop.getPortURI(),
						Heater.EXTERNAL_CONTROL_INBOUND_PORT_URI,
						HeaterConnector.class.getCanonicalName());
			}

			// Connect to WashingMachine for energy management
			/*
			 * this.washingMachineop = new AdjustableOutboundPort(this);
			 * this.washingMachineop.publishPort();
			 * this.doPortConnection(
			 * this.washingMachineop.getPortURI(),
			 * WashingMachineCyPhy.EXTERNAL_CONTROL_INBOUND_PORT_URI,
			 * WashingMachineConnector.class.getCanonicalName());
			 * 
			 * // Connect to Kettle for energy management
			 * this.kettleop = new AdjustableOutboundPort(this);
			 * this.kettleop.publishPort();
			 * this.doPortConnection(
			 * this.kettleop.getPortURI(),
			 * KettleCyPhy.EXTERNAL_CONTROL_INBOUND_PORT_URI,
			 * KettleConnector.class.getCanonicalName());
			 */
		} catch (Throwable e) {
			throw new ComponentStartException(e);
		}
	}

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#execute()
	 */
	@Override
	public synchronized void execute() throws Exception {
		this.traceMessage("HEM begins execution.\n");

		switch (this.executionMode) {
			case STANDARD:
			case UNIT_TEST:
			case UNIT_TEST_WITH_SIL_SIMULATION:
				throw new BCMException("No unit test for HEM!");
			case INTEGRATION_TEST:
				this.initialiseClock(
						ClocksServer.STANDARD_INBOUNDPORT_URI,
						this.testScenario.getClockURI());
				this.executeTestScenario(this.testScenario);
				break;
			case INTEGRATION_TEST_WITH_SIL_SIMULATION:
				this.initialiseClock(
						ClocksServerWithSimulation.STANDARD_INBOUNDPORT_URI,
						this.testScenario.getClockURI());
				this.executeTestScenario(this.testScenario);
				break;
			case UNIT_TEST_WITH_HIL_SIMULATION:
			case INTEGRATION_TEST_WITH_HIL_SIMULATION:
				throw new BCMException("HIL simulation not implemented yet!");
			default:
		}
		this.traceMessage("HEM ends execution.\n");

		// if (this.performTest) {
		// this.logMessage("Electric meter tests start.");
		// this.testMeter();
		// this.logMessage("Electric meter tests end.");
		// this.logMessage("Batteries tests start.");
		// this.testBatteries();
		// this.logMessage("Batteries tests end.");
		// this.logMessage("Solar Panel tests start.");
		// this.testSolarPanel();
		// this.logMessage("Solar Panel tests end.");
		// this.logMessage("Generator tests start.");
		// this.testGenerator();
		// this.logMessage("Generator tests end.");
		// if (this.isPreFirstStep) {
		// this.scheduleTestHeater();
		// }
		// }
	}

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#finalise()
	 */
	@Override
	public synchronized void finalise() throws Exception {
		this.doPortDisconnection(this.meterop.getPortURI());
		this.doPortDisconnection(this.batteriesop.getPortURI());
		this.doPortDisconnection(this.solarPanelop.getPortURI());
		this.doPortDisconnection(this.generatorop.getPortURI());
		if (this.isPreFirstStep) {
			this.doPortDisconnection(this.heaterop.getPortURI());
		}
		// this.doPortDisconnection(this.washingMachineop.getPortURI());
		// this.doPortDisconnection(this.kettleop.getPortURI());
		for (Map.Entry<String, AdjustableOutboundPort> entry : this.registeredEquipments.entrySet()) {
			try {
				AdjustableOutboundPort port = entry.getValue();
				if (port.connected()) {
					this.doPortDisconnection(port.getPortURI());
				}
			} catch (Throwable e) {
				// ignorer les erreurs de déconnexion
			}
		}
		super.finalise();
	}

	/**
	 * @see fr.sorbonne_u.components.AbstractComponent#shutdown()
	 */
	@Override
	public synchronized void shutdown() throws ComponentShutdownException {
		try {
			this.meterop.unpublishPort();
			this.batteriesop.unpublishPort();
			this.solarPanelop.unpublishPort();
			this.generatorop.unpublishPort();
			if (this.isPreFirstStep) {
				this.heaterop.unpublishPort();
			}
			// this.washingMachineop.unpublishPort();
			// this.kettleop.unpublishPort();
			for (AdjustableOutboundPort port : this.registeredEquipments.values()) {
				try {
					if (port.isPublished()) {
						port.unpublishPort();
					}
				} catch (Throwable e) {
					// ignorer
				}
			}
			// Dépublication du port d'enregistrement
			if (this.registrationInboundPort.isPublished()) {
				this.registrationInboundPort.unpublishPort();
			}
		} catch (Throwable e) {
			throw new ComponentShutdownException(e);
		}
		super.shutdown();
	}

	// -------------------------------------------------------------------------
	// Registration methods (RegistrationImplementorI) — Étape 4
	// -------------------------------------------------------------------------

	/**
	 * @see fr.sorbonne_u.components.hem2025e1.equipments.hem.RegistrationInboundPort.RegistrationImplementorI#registered(String)
	 */
	@Override
	public boolean registered(String uid) throws Exception {
		if (uid == null || uid.isEmpty()) {
			return false;
		}
		return this.registeredEquipments.containsKey(uid);
	}

	/**
	 * @see fr.sorbonne_u.components.hem2025e1.equipments.hem.RegistrationInboundPort.RegistrationImplementorI#register(String,
	 *      String, String)
	 */
	@Override
	public boolean register(
			String uid,
			String controlPortURI,
			String xmlControlAdapter) throws Exception {
		assert uid != null && !uid.isEmpty()
				: new PreconditionException("uid != null && !uid.isEmpty()");
		assert controlPortURI != null && !controlPortURI.isEmpty()
				: new PreconditionException(
						"controlPortURI != null && !controlPortURI.isEmpty()");

		if (this.registeredEquipments.containsKey(uid)) {
			this.traceMessage("HEMCyPhy: equipment " + uid
					+ " already registered, skipping.\n");
			return false;
		}

		this.traceMessage("HEMCyPhy: registering equipment " + uid + "...\n");

		try {
			// Lecture du descripteur XML et génération du connecteur dynamique
			AdapterDescriptor descriptor = DescriptorReader.readFrom(xmlControlAdapter);
			String generatedClassName = "fr.sorbonne_u.components.hem2025e3.generated."
					+ "DynConnector_" + uid + "_"
					+ (++this.connectorCounter);
			Class<?> connectorClass = DynamicConnectorFactory.fabricate(
					descriptor, generatedClassName);

			// Création du port sortant et connexion dynamique
			AdjustableOutboundPort aop = new AdjustableOutboundPort(this);
			aop.publishPort();
			this.doPortConnection(
					aop.getPortURI(),
					controlPortURI,
					connectorClass.getName());

			this.registeredEquipments.put(uid, aop);

			this.traceMessage("HEMCyPhy: equipment " + uid
					+ " registered successfully via dynamic connector "
					+ connectorClass.getSimpleName() + ".\n");
			return true;
		} catch (Exception e) {
			this.traceMessage("HEMCyPhy: registration failed for " + uid
					+ " — " + e.getMessage() + "\n");
			return false;
		}
	}

	/**
	 * @see fr.sorbonne_u.components.hem2025e1.equipments.hem.RegistrationInboundPort.RegistrationImplementorI#unregister(String)
	 */
	@Override
	public void unregister(String uid) throws Exception {
		assert uid != null && !uid.isEmpty()
				: new PreconditionException("uid != null && !uid.isEmpty()");

		AdjustableOutboundPort port = this.registeredEquipments.remove(uid);
		if (port != null) {
			if (port.connected()) {
				this.doPortDisconnection(port.getPortURI());
			}
			if (port.isPublished()) {
				port.unpublishPort();
			}
			this.traceMessage("HEMCyPhy: equipment " + uid
					+ " unregistered successfully.\n");
		} else {
			this.traceMessage("HEMCyPhy: equipment " + uid
					+ " was not registered.\n");
		}
	}

	// -------------------------------------------------------------------------
	// Test helper methods
	// -------------------------------------------------------------------------

	/**
	 * test the {@code ElectricMeter} component.
	 * 
	 * <p>
	 * <strong>Description</strong>
	 * </p>
	 * 
	 * <p>
	 * Calls the test methods defined in {@code ElectricMeterUnitTester}.
	 * </p>
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @throws Exception <i>to do</i>.
	 */
	public void testMeter() throws Exception {
		ElectricMeterUnitTester.runAllTests(this, this.meterop,
				new TestsStatistics());
	}

	/**
	 * test the {@code Batteries} component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 * 
	 * @throws Exception <i>to do</i>.
	 *
	 */
	public void testBatteries() throws Exception {
		BatteriesCyPhyUnitTester.runAllTests(this, this.batteriesop,
				new TestsStatistics());
	}

	/**
	 * start charging the batteries.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @throws Exception <i>to do</i>.
	 */
	public void startChargingBatteries() throws Exception {
		this.batteriesop.startCharging();
	}

	/**
	 * test the state of the batteries.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @throws Exception <i>to do</i>.
	 */
	public void testBatteriesState() throws Exception {
		this.logMessage("areCharging = " + this.batteriesop.areCharging());
		this.logMessage("areDischarging = " + this.batteriesop.areDischarging());
		this.logMessage("chargeLevel = " + this.batteriesop.chargeLevel());
		this.logMessage("getCurrentPowerConsumption = " + this.batteriesop.getCurrentPowerConsumption());
	}

	/**
	 * stop charging the batteries.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @throws Exception <i>to do</i>.
	 */
	public void stopChargingBatteries() throws Exception {
		this.batteriesop.stopCharging();
	}

	/**
	 * return the outbound port connected to the generator component; used in
	 * test scenario.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @return the outbound port connected to the generator component.
	 */
	public GeneratorOutboundPort getGeneratorPort() {
		return this.generatorop;
	}

	/**
	 * test the {@code SolarPanel} component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 * 
	 * @throws Exception <i>to do</i>.
	 *
	 */
	public void testSolarPanel() throws Exception {
		SolarPanelUnitTesterCyPhy.runAllTests(this, this.solarPanelop,
				new TestsStatistics());
	}

	/**
	 * test the {@code Generator} component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 * 
	 * @throws Exception <i>to do</i>.
	 *
	 */
	public void testGenerator() throws Exception {
		GeneratorUnitTester.runAllTests(this, this.generatorop,
				new TestsStatistics());
	}

	/**
	 * test the heater.
	 * 
	 * <p>
	 * <strong>Gherkin specification</strong>
	 * </p>
	 * 
	 * <pre>
	 * Feature: adjustable appliance mode management
	 *   Scenario: getting the max mode index
	 *     Given the heater has just been turned on
	 *     When I call maxMode()
	 *     Then the result is its max mode index
	 *   Scenario: getting the current mode index
	 *     Given the heater has just been turned on
	 *     When I call currentMode()
	 *     Then the current mode is its max mode
	 *   Scenario: going down one mode index
	 *     Given the heater is turned on
	 *     And the current mode index is the max mode index
	 *     When I call downMode()
	 *     Then the method returns true
	 *     And the current mode is its max mode minus one
	 *   Scenario: going up one mode index
	 *     Given the heater is turned on
	 *     And the current mode index is the max mode index minus one
	 *     When I call upMode()
	 *     Then the method returns true
	 *     And the current mode is its max mode
	 *   Scenario: setting the mode index
	 *     Given the heater is turned on
	 *     And the mode index 1 is legitimate
	 *     When I call setMode(1)
	 *     Then the method returns true
	 *     And the current mode is 1
	 * Feature: Getting the power consumption given a mode
	 *   Scenario: getting the power consumption of the maximum mode
	 *     Given the heater is turned on
	 *     When I get the power consumption of the maximum mode
	 *     Then the result is the maximum power consumption of the heater
	 * Feature: suspending and resuming
	 *   Scenario: checking if suspended when not
	 *     Given the heater is turned on
	 *     And it has not been suspended yet
	 *     When I check if suspended
	 *     Then it is not
	 *   Scenario: suspending
	 *     Given the heater is turned on
	 *     And it is not suspended
	 *     When I call suspend()
	 *     Then the method returns true
	 *     And the heater is suspended
	 *   Scenario: going down one mode index when suspended
	 *     Given the heater is turned on
	 *     And the heater is suspended
	 *     When I call downMode()
	 *     Then a precondition exception is thrown
	 *   Scenario: going up one mode index when suspended
	 *     Given the heater is turned on
	 *     And the heater is suspended
	 *     When I call upMode()
	 *     Then a precondition exception is thrown
	 *   Scenario: going up one mode index when suspended
	 *     Given the heater is turned on
	 *     And the heater is suspended
	 *     When I call upMode()
	 *     Then a precondition exception is thrown
	 *   Scenario: getting the current mode when suspended
	 *     Given the heater is turned on
	 *     And the heater is suspended
	 *     When I get the current mode
	 *     Then a precondition exception is thrown
	 *   Scenario: checking the emergency
	 *     Given the heater is turned on
	 *     And it has just been suspended
	 *     When I call emergency()
	 *     Then the emergency is between 0.0 and 1.0
	 *   Scenario: resuming
	 *     Given the heater is turned on
	 *     And it is suspended
	 *     When I call resume()
	 *     Then the method returns true
	 *     And the heater is not suspended
	 * </pre>
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 * @throws Exception <i>to do</i>.
	 */
	public void testHeater() throws Exception {
		this.logMessage("Heater tests start.");
		TestsStatistics statistics = new TestsStatistics();
		try {
			this.logMessage("Feature: adjustable appliance mode management");
			this.logMessage("  Scenario: getting the max mode index");
			this.logMessage("    Given the heater has just been turned on");
			this.logMessage("    When I call maxMode()");
			this.logMessage("    Then the result is its max mode index");
			final int maxMode = heaterop.maxMode();

			statistics.updateStatistics();

			this.logMessage("  Scenario: getting the current mode index");
			this.logMessage("    Given the heater has just been turned on");
			this.logMessage("    When I call currentMode()");
			this.logMessage("    Then the current mode is its max mode");
			int result = heaterop.currentMode();
			if (result != maxMode) {
				this.logMessage("      but was: " + result);
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: going down one mode index");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the current mode index is the max mode index");
			result = heaterop.currentMode();
			if (result != maxMode) {
				this.logMessage("      but was: " + result);
				statistics.failedCondition();
			}
			this.logMessage("    When I call downMode()");
			this.logMessage("    Then the method returns true");
			boolean bResult = heaterop.downMode();
			if (!bResult) {
				this.logMessage("      but was: " + bResult);
				statistics.incorrectResult();
			}
			this.logMessage("    And the current mode is its max mode minus one");
			result = heaterop.currentMode();
			if (result != maxMode - 1) {
				this.logMessage("      but was: " + result);
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: going up one mode index");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the current mode index is the max mode index minus one");
			result = heaterop.currentMode();
			if (result != maxMode - 1) {
				this.logMessage("      but was: " + result);
				statistics.failedCondition();
			}
			this.logMessage("    When I call upMode()");
			this.logMessage("    Then the method returns true");
			bResult = heaterop.upMode();
			if (!bResult) {
				this.logMessage("      but was: " + bResult);
				statistics.incorrectResult();
			}
			this.logMessage("    And the current mode is its max mode");
			result = heaterop.currentMode();
			if (result != maxMode) {
				this.logMessage("      but was: " + result);
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: setting the mode index");
			this.logMessage("    Given the heater is turned on");
			int index = 1;
			this.logMessage("    And the mode index 1 is legitimate");
			if (index > maxMode) {
				this.logMessage("      but was not!");
				statistics.failedCondition();
			}
			this.logMessage("    When I call setMode(1)");
			this.logMessage("    Then the method returns true");
			bResult = heaterop.setMode(1);
			if (!bResult) {
				this.logMessage("      but was: " + bResult);
				statistics.incorrectResult();
			}
			this.logMessage("    And the current mode is 1");
			result = heaterop.currentMode();
			if (result != 1) {
				this.logMessage("      but was: " + result);
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("Feature: Getting the power consumption given a mode");
			this.logMessage("  Scenario: getting the power consumption of the maximum mode");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    When I get the power consumption of the maximum mode");
			double dResult = heaterop.getModeConsumption(maxMode);
			this.logMessage("    Then the result is the maximum power consumption of the heater");

			statistics.updateStatistics();

			this.logMessage("Feature: suspending and resuming");
			this.logMessage("  Scenario: checking if suspended when not");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And it has not been suspended yet");
			this.logMessage("    When I check if suspended");
			bResult = heaterop.suspended();
			this.logMessage("    Then it is not");
			if (bResult) {
				this.logMessage("      but it was!");
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: suspending");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And it is not suspended");
			bResult = heaterop.suspended();
			if (bResult) {
				this.logMessage("      but it was!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I call suspend()");
			bResult = heaterop.suspend();
			this.logMessage("    Then the method returns true");
			if (!bResult) {
				this.logMessage("      but was: " + bResult);
				statistics.incorrectResult();
			}
			this.logMessage("    And the heater is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: going down one mode index when suspended");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the heater is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I call downMode()");
			this.logMessage("    Then a precondition exception is thrown");
			boolean old = BCMException.VERBOSE;
			try {
				BCMException.VERBOSE = false;
				heaterop.downMode();
				this.logMessage("      but it was not!");
				statistics.incorrectResult();
			} catch (Throwable e) {
			} finally {
				BCMException.VERBOSE = old;
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: going up one mode index when suspended");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the heater is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I call upMode()");
			this.logMessage("    Then a precondition exception is thrown");
			old = BCMException.VERBOSE;
			try {
				BCMException.VERBOSE = false;
				heaterop.upMode();
				this.logMessage("      but it was not!");
				statistics.incorrectResult();
			} catch (Throwable e) {
			} finally {
				BCMException.VERBOSE = old;
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: setting the mode when suspended");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the heater is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    And the mode index 1 is legitimate");
			if (index > maxMode) {
				this.logMessage("      but was not!");
				statistics.failedCondition();
			}
			this.logMessage("    When I call setMode(1)");
			this.logMessage("    Then a precondition exception is thrown");
			old = BCMException.VERBOSE;
			try {
				BCMException.VERBOSE = false;
				heaterop.upMode();
				this.logMessage("      but it was not!");
				statistics.incorrectResult();
			} catch (Throwable e) {
			} finally {
				BCMException.VERBOSE = old;
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: getting the current mode when suspended");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And the heater is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I get the current mode");
			this.logMessage("    Then a precondition exception is thrown");
			old = BCMException.VERBOSE;
			try {
				BCMException.VERBOSE = false;
				heaterop.currentMode();
				this.logMessage("      but it was not!");
				statistics.incorrectResult();
			} catch (Throwable e) {
			} finally {
				BCMException.VERBOSE = old;
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: checking the emergency");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And it has just been suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I call emergency()");
			dResult = heaterop.emergency();
			this.logMessage("    Then the emergency is between 0.0 and 1.0");
			if (dResult < 0.0 || dResult > 1.0) {
				this.logMessage("      but was: " + dResult);
				statistics.incorrectResult();
			}

			statistics.updateStatistics();

			this.logMessage("  Scenario: resuming");
			this.logMessage("    Given the heater is turned on");
			this.logMessage("    And it is suspended");
			bResult = heaterop.suspended();
			if (!bResult) {
				this.logMessage("      but it was not!");
				statistics.failedCondition();
				;
			}
			this.logMessage("    When I call resume()");
			bResult = heaterop.resume();
			this.logMessage("    Then the method returns true");
			if (!bResult) {
				this.logMessage("      but was: " + bResult);
				statistics.incorrectResult();
			}
			this.logMessage("    And the heater is not suspended");
			bResult = heaterop.suspended();
			if (bResult) {
				this.logMessage("      but it was!");
				statistics.incorrectResult();
			}
		} catch (Throwable e) {
			e.printStackTrace();
		}

		statistics.updateStatistics();
		statistics.statisticsReport(this);

		this.logMessage("Heater tests end.");
	}

	/**
	 * test the {@code Heater} component, in cooperation with the
	 * {@code HeaterTester} component.
	 * 
	 * <p>
	 * <strong>Contract</strong>
	 * </p>
	 * 
	 * <pre>
	 * pre	{@code
	 * true
	 * }	// no precondition.
	 * post	{@code
	 * true
	 * }	// no postcondition.
	 * </pre>
	 *
	 */
	// protected void scheduleTestHeater()
	// {
	// // Test for the heater
	// Instant heaterTestStart =
	// this.ac.getStartInstant().plusSeconds(
	// (HeaterUnitTester.SWITCH_ON_DELAY +
	// HeaterUnitTester.SWITCH_OFF_DELAY)/2);
	// this.traceMessage("HEM schedules the heater test.\n");
	// long delay = this.ac.nanoDelayUntilInstant(heaterTestStart);
	//
	// // schedule the switch on heater in one second
	// this.scheduleTaskOnComponent(
	// new AbstractComponent.AbstractTask() {
	// @Override
	// public void run() {
	// try {
	// testHeater();
	// } catch (Throwable e) {
	// throw new BCMRuntimeException(e) ;
	// }
	// }
	// }, delay, TimeUnit.NANOSECONDS);
	// }

	// -------------------------------------------------------------------------
	// WashingMachine control methods
	// -------------------------------------------------------------------------

	/** UID de la WashingMachine pour l'enregistrement dynamique. */
	public static final String WM_UID = "WM10000";

	/**
	 * Test the WashingMachine AdjustableCI interface via HEM.
	 * Uses the dynamically registered port.
	 * 
	 * @throws Exception if an error occurs
	 */
	public void testWashingMachine() throws Exception {
		this.logMessage("WashingMachine HEM tests start.");
		AdjustableOutboundPort wmop = this.registeredEquipments.get(WM_UID);
		if (wmop == null) {
			this.logMessage("WashingMachine not registered yet, skipping tests.");
			return;
		}
		TestsStatistics statistics = new TestsStatistics();
		try {
			this.logMessage("Feature: adjustable appliance mode management for WashingMachine");

			this.logMessage("  Scenario: getting the max mode index");
			// final int maxMode = washingMachineop.maxMode();
			final int maxMode = wmop.maxMode();
			this.logMessage("    Max mode: " + maxMode);
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended when not");
			// boolean isSuspended = washingMachineop.suspended();
			boolean isSuspended = wmop.suspended();
			if (isSuspended) {
				this.logMessage("    ERROR: should not be suspended initially");
				statistics.incorrectResult();
			} else {
				this.logMessage("    OK: not suspended initially");
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: suspending the washing machine");
			// boolean suspendResult = washingMachineop.suspend();
			boolean suspendResult = wmop.suspend();
			if (suspendResult) {
				this.logMessage("    OK: suspend() returned true");
			} else {
				this.logMessage("    ERROR: suspend() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended after suspend");
			// isSuspended = washingMachineop.suspended();
			isSuspended = wmop.suspended();
			if (isSuspended) {
				this.logMessage("    OK: is suspended after suspend()");
			} else {
				this.logMessage("    ERROR: should be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: getting emergency level when suspended");
			// double emergency = washingMachineop.emergency();
			double emergency = wmop.emergency();
			this.logMessage("    Emergency level: " + emergency);
			statistics.updateStatistics();

			this.logMessage("  Scenario: resuming the washing machine");
			// boolean resumeResult = washingMachineop.resume();
			boolean resumeResult = wmop.resume();
			if (resumeResult) {
				this.logMessage("    OK: resume() returned true");
			} else {
				this.logMessage("    ERROR: resume() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if not suspended after resume");
			// isSuspended = washingMachineop.suspended();
			isSuspended = wmop.suspended();
			if (!isSuspended) {
				this.logMessage("    OK: not suspended after resume()");
			} else {
				this.logMessage("    ERROR: should not be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

		} catch (Exception e) {
			this.logMessage("Exception during WashingMachine test: " + e.getMessage());
			statistics.incorrectResult();
		}
		this.logMessage("WashingMachine HEM tests end. " + statistics);
	}

	// -------------------------------------------------------------------------
	// Kettle control methods
	// -------------------------------------------------------------------------

	/** UID de la Kettle pour l'enregistrement dynamique. */
	public static final String KT_UID = "KT10000";
	public static final String FAN_UID = "FN10000";

	/**
	 * Test the Kettle AdjustableCI interface via HEM.
	 * Uses the dynamically registered port.
	 * 
	 * @throws Exception if an error occurs
	 */
	public void testKettle() throws Exception {
		this.logMessage("Kettle HEM tests start.");
		AdjustableOutboundPort ktop = this.registeredEquipments.get(KT_UID);
		if (ktop == null) {
			this.logMessage("Kettle not registered yet, skipping tests.");
			return;
		}
		TestsStatistics statistics = new TestsStatistics();
		try {
			this.logMessage("Feature: adjustable appliance mode management for Kettle");

			this.logMessage("  Scenario: getting the max mode index");
			// final int maxMode = kettleop.maxMode();
			final int maxMode = ktop.maxMode();
			this.logMessage("    Max mode: " + maxMode);
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended when not");
			// boolean isSuspended = kettleop.suspended();
			boolean isSuspended = ktop.suspended();
			if (isSuspended) {
				this.logMessage("    ERROR: should not be suspended initially");
				statistics.incorrectResult();
			} else {
				this.logMessage("    OK: not suspended initially");
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: suspending the kettle");
			// boolean suspendResult = kettleop.suspend();
			boolean suspendResult = ktop.suspend();
			if (suspendResult) {
				this.logMessage("    OK: suspend() returned true");
			} else {
				this.logMessage("    ERROR: suspend() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended after suspend");
			// isSuspended = kettleop.suspended();
			isSuspended = ktop.suspended();
			if (isSuspended) {
				this.logMessage("    OK: is suspended after suspend()");
			} else {
				this.logMessage("    ERROR: should be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: getting emergency level when suspended");
			// double emergency = kettleop.emergency();
			double emergency = ktop.emergency();
			this.logMessage("    Emergency level: " + emergency);
			statistics.updateStatistics();

			this.logMessage("  Scenario: resuming the kettle");
			//
			boolean resumeResult = ktop.resume();
			if (resumeResult) {
				this.logMessage("    OK: resume() returned true");
			} else {
				this.logMessage("    ERROR: resume() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if not suspended after resume");
			// isSuspended = kettleop.suspended();
			isSuspended = ktop.suspended();
			if (!isSuspended) {
				this.logMessage("    OK: not suspended after resume()");
			} else {
				this.logMessage("    ERROR: should not be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

		} catch (Exception e) {
			this.logMessage("Exception during Kettle test: " + e.getMessage());
			statistics.incorrectResult();
		}
		this.logMessage("Kettle HEM tests end. " + statistics);
	}

	/**
	 * test the fan through the HEM adjustable interface.
	 * 
	 * @throws Exception if an error occurs.
	 */
	public void testFan() throws Exception {
		this.logMessage("Fan HEM tests start.");
		AdjustableOutboundPort fnop = this.registeredEquipments.get(FAN_UID);
		if (fnop == null) {
			this.logMessage("Fan not registered yet, skipping tests.");
			return;
		}
		TestsStatistics statistics = new TestsStatistics();
		try {
			this.logMessage("Feature: adjustable appliance mode management for Fan");

			this.logMessage("  Scenario: getting the max mode index");
			final int maxMode = fnop.maxMode();
			this.logMessage("    Max mode: " + maxMode);
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended when not");
			boolean isSuspended = fnop.suspended();
			if (isSuspended) {
				this.logMessage("    ERROR: should not be suspended initially");
				statistics.incorrectResult();
			} else {
				this.logMessage("    OK: not suspended initially");
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: suspending the fan");
			boolean suspendResult = fnop.suspend();
			if (suspendResult) {
				this.logMessage("    OK: suspend() returned true");
			} else {
				this.logMessage("    ERROR: suspend() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if suspended after suspend");
			isSuspended = fnop.suspended();
			if (isSuspended) {
				this.logMessage("    OK: is suspended after suspend()");
			} else {
				this.logMessage("    ERROR: should be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: getting emergency level when suspended");
			double emergency = fnop.emergency();
			this.logMessage("    Emergency level: " + emergency);
			statistics.updateStatistics();

			this.logMessage("  Scenario: resuming the fan");
			boolean resumeResult = fnop.resume();
			if (resumeResult) {
				this.logMessage("    OK: resume() returned true");
			} else {
				this.logMessage("    ERROR: resume() returned false");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

			this.logMessage("  Scenario: checking if not suspended after resume");
			isSuspended = fnop.suspended();
			if (!isSuspended) {
				this.logMessage("    OK: not suspended after resume()");
			} else {
				this.logMessage("    ERROR: should not be suspended");
				statistics.incorrectResult();
			}
			statistics.updateStatistics();

		} catch (Exception e) {
			this.logMessage("Exception during Fan test: " + e.getMessage());
			statistics.incorrectResult();
		}
		this.logMessage("Fan HEM tests end. " + statistics);
	}

	/**
	 * Energy management control loop - suspends WashingMachine when
	 * production is lower than consumption.
	 * Uses the dynamically registered WashingMachine port.
	 * 
	 * @throws Exception if an error occurs
	 */
	public void manageEnergy() throws Exception {
		this.logMessage("HEM Energy Management starts.");

		AdjustableOutboundPort wmop = this.registeredEquipments.get(WM_UID);
		if (wmop == null) {
			this.logMessage("  WashingMachine not registered, cannot manage energy.");
			this.logMessage("HEM Energy Management ends.");
			return;
		}

		// Get current power levels from meter
		double totalConsumption = this.meterop.getCurrentConsumption().getMeasure().getData();
		double totalProduction = this.meterop.getCurrentProduction().getMeasure().getData();

		this.logMessage("  Current consumption: " + totalConsumption + " W");
		this.logMessage("  Current production: " + totalProduction + " W");

		if (totalConsumption > totalProduction) {
			this.logMessage("  WARNING: Consumption > Production!");

			// Try to suspend WashingMachine if not already suspended
			// if (!this.washingMachineop.suspended()) {
			if (!wmop.suspended()) {
				this.logMessage("  Attempting to suspend WashingMachine...");
				// boolean result = this.washingMachineop.suspend();
				boolean result = wmop.suspend();
				if (result) {
					this.logMessage("  WashingMachine suspended successfully.");
				} else {
					this.logMessage("  Failed to suspend WashingMachine.");
				}
			} else {
				this.logMessage("  WashingMachine already suspended.");
			}
		} else {
			this.logMessage("  Production >= Consumption, OK.");

			// Resume WashingMachine if suspended
			// if (this.washingMachineop.suspended()) {
			// double emergency = this.washingMachineop.emergency();
			if (wmop.suspended()) {
				double emergency = wmop.emergency();
				this.logMessage("  WashingMachine emergency level: " + emergency);

				// Resume if there's enough margin or high emergency
				if (totalProduction - totalConsumption > 500.0 || emergency > 0.5) {
					this.logMessage("  Resuming WashingMachine...");
					// boolean result = this.washingMachineop.resume();
					boolean result = wmop.resume();
					if (result) {
						this.logMessage("  WashingMachine resumed successfully.");
					} else {
						this.logMessage("  Failed to resume WashingMachine.");
					}
				}
			}
		}

		this.logMessage("HEM Energy Management ends.");
	}
}
// -----------------------------------------------------------------------------
